Clients samples for TSCA


These clients use the thrift arbiter interface to submit services and hosts
checks results (similar to NSCA server modules).

They read their input from a csv file and send it to shinken.
