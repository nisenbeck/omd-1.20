% shinken-admin(8) Shinken User Manuals
% David Hannequin
% Arthur Gautier
% Michael Leinartas
% December 29, 2011

# NAME

shinken-admin - Shinken admin shell

# SYNOPSIS

shinken-admin

# DESCRIPTION

Shinken admin shell

Invokes a simple shell interface for interacting with shinken-arbiter
