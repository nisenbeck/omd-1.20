ALTER TABLE icinga_hosts ALTER COLUMN failure_prediction_options TYPE varchar(255);
ALTER TABLE icinga_services ALTER COLUMN failure_prediction_options TYPE varchar(255);
